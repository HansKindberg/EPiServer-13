define(["exports"],function(e){"use strict";function n(){var t;return(t=window.state)==null?void 0:t.get("contentState")}function o(){var t;return(t=window.state)==null?void 0:t.get("projectState")}e.getContentState=n,e.getProjectState=o});
//# sourceMappingURL=state-helpers_2.js.map
