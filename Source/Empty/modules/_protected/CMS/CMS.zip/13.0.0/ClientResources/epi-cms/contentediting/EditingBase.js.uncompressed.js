define("epi-cms/contentediting/EditingBase", [
    // Dojo
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/Deferred",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/query",
    "dojo/topic",
    "dojo/when",
    // EPi Framework
    "epi/dependency",
    "epi/string",
    "epi/shell/DestroyableByKey",
    // EPi CMS
    "epi-cms/ApplicationSettings",
    "epi-cms/contentediting/MutationObserver",
    "epi-cms/contentediting/_View",
    "epi-cms/contentediting/MappingManager",
    "epi-cms/contentediting/RenderManager",
    "epi-cms/contentediting/UpdateController",
    "epi-cms/widget/overlay/overlayFactory",
    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting"
], function (
// Dojo
array, connect, declare, Deferred, lang, aspect, query, topic, when, 
// EPi Framework
dependency, epiString, DestroyableByKey, 
// EPi CMS
ApplicationSettings, MutationObserver, _View, MappingManager, RenderManager, UpdateController, overlayFactory, 
// Resources
res) {
    return declare([_View, DestroyableByKey], {
        // tags:
        //      internal
        // editorFactory: [epi-cms/contentediting/EditorFactory]
        //      Editor factory instance.
        editorFactory: null,
        // activePropertyOnStartup: [String]
        //      Property to be set as active when edit view has done setting up.
        activePropertyOnStartup: null,
        // createOverlays: [Boolean]
        //      Indicate that the overlays should be created.
        createOverlays: true,
        _renderManager: null,
        _mappingManager: null,
        _activeEditorWrapper: null,
        _deferredReloadHandle: null,
        _eventHandlers: null,
        _isCreatingWrapper: null,
        // _mutationObserver: [private] epi-cms/contentediting/MutationObserver
        //      MutationObserver instance
        _mutationObserver: null,
        postMixInProperties: function () {
            this.inherited(arguments);
            this.editorFactory = this.editorFactory || dependency.resolve("epi.cms.contentediting.EditorFactory");
            this._mappingManager = new MappingManager();
            this._mutationObserver = new MutationObserver();
            this.own(this._mutationObserver.on("dom-updated", function () {
                this.emit("dom-updated");
            }.bind(this)));
            this._eventHandlers = [];
            this._hashWrapper = this._hashWrapper || dependency.resolve("epi.shell.HashWrapper");
        },
        destroy: function () {
            this._stopActiveEditorWrapper();
            if (this._renderManager) {
                this._renderManager.destroy();
            }
            this._mappingManager.clear();
            // Remove all overlay items that was added
            this.overlay.destroyDescendants();
            // Teardown mutation observers
            this._mutationObserver.teardown();
            this.inherited(arguments);
        },
        onReloadRequired: function () {
            this.inherited(arguments);
            // clear and suspend render manager after the watch handlers finished
            setTimeout(function () {
                this._renderManager.suspend();
                this._renderManager.clear();
            }.bind(this), 0);
        },
        _setViewModelAttr: function (viewModel) {
            if (viewModel === this.viewModel) {
                return;
            }
            this.inherited(arguments);
            //Disconnect all event handlers
            this.destroyByKey("viewModel");
            //Listen to onSuspend and stop editing the property and reset active editor
            this.ownByKey("viewModel", connect.connect(this.viewModel, "onContentChange", this, this._stopActiveEditorWrapper));
            // Listen on onSetActiveProperty event so it can react when active property is about to set on ContentViewModel
            this.ownByKey("viewModel", connect.connect(this.viewModel, "onSetActiveProperty", this, this.onSetActiveProperty));
            // Listen to onPropertyReverted to handle property value rollback
            this.ownByKey("viewModel", connect.connect(this.viewModel, "onPropertyReverted", this, this._onPropertyReverted));
            this.ownByKey("viewModel", topic.subscribe("/dnd/start", function () {
                // this timeout lets the previous operation end before starting the new one
                setTimeout(this.beginOperation.bind(this), 0);
            }.bind(this.viewModel)));
            this.ownByKey("viewModel", topic.subscribe("/dnd/stop", lang.hitch(this, function () {
                // If we have an active editor do not end the operation
                if (this._activeEditorWrapper) {
                    return;
                }
                this.viewModel.endOperation();
            })));
        },
        _stopActiveEditorWrapper: function () {
            if (this._activeEditorWrapper != null && this._activeEditorWrapper.domNode) {
                when(this._activeEditorWrapper.tryToStopEditing(), lang.hitch(this, function () {
                    this._activeEditorWrapper = null;
                }));
            }
        },
        onSetActiveProperty: function (property) {
            // summary:
            //      Triggered when active property is set on the current content view model.
            // property: String
            //      The property name.
            // tags:
            //      public, callback
        },
        onPreviewReady: function (viewModel, doc, forceSetup, props) {
            // summary:
            //      Triggered when preview is ready.
            // viewModel: [epi.cms.contentediting.ContentViewModel]
            //      The content view model.
            // doc: [Document]
            //      The preview document.
            // forceSetup: [Boolean]
            //      Indicate that the preview ready along with significant model changes, therefore the editing stuff must be setup again.
            // tags:
            //      public, callback.
            if (!doc && !props) {
                return;
            }
            if (forceSetup || viewModel !== this.viewModel) {
                this.set("viewModel", viewModel);
                this.setupEditMode(doc, props);
            }
            else if (viewModel) {
                this.remapEditMode(doc, props);
            }
        },
        setupEditMode: function (doc, props) {
            // summary:
            //      Setup all necessary stuff for edit mode.
            // tags:
            //      protected
            this.viewModel.reload().then(lang.hitch(this, function () {
                // reset
                this._mappingManager.clear();
                if (this._renderManager) {
                    this._renderManager.clear();
                }
                this._renderManager = new RenderManager();
                this.viewModel.resetNotifications();
                // remove existing handles
                this._destroyOverlay();
                this.onReadySetupEditMode(doc, props);
                // Setup mutation observers
                this._mutationObserver.setup(doc);
                // Set the doc to null to avoid closure leakage
                doc = null;
                this.onPrepareOverlayComplete();
            }));
        },
        remapEditMode: function (doc, props) {
            // summary:
            //      Re-configure edit mode after the preview context changed.
            // tags:
            //      protected
            this.viewModel.reload().then(lang.hitch(this, function () {
                this._renderManager.resume();
                // When loading blocks that required reload, wait for blocks rendered then remap update controller
                if (doc) {
                    setTimeout(lang.hitch(this, function () {
                        this._remapUpdateControllers(doc, props);
                        this.onPrepareOverlayComplete();
                        // Setup mutation observers
                        this._mutationObserver.setup(doc);
                    }), 1);
                }
            }));
        },
        _destroyOverlay: function () {
            // summary:
            //      Destroy the handles owned by the overlay items and view model
            // tags:
            //      protected, internal
            this.destroyByKey("overlay");
        },
        onReadySetupEditMode: function (doc, props) {
            // summary:
            //    Edit mode is ready for setting up.
            //
            // description:
            //    Setup editable blocks. Override to do extra setup, for example: set up form editing.
            //
            // propertyMetadataMap: Object
            //    Property metadata hashmap.
            //
            // tags:
            //    protected
            this._createUpdateControllers(doc, props);
        },
        onSetupEditModeComplete: function () {
            // summary:
            //      Triggered when edit mode is successfully set up.
            // remark:
            //      Should be fired by concrete edit view when it finishes preparations.
            // tags:
            //      public, callback.
            // Try extract activeproperty from hash
            this.activePropertyOnStartup = this._hashWrapper.consume("activeproperty") || this.activePropertyOnStartup;
            // Set active property if exists.
            if (this.activePropertyOnStartup) {
                this.onSetActiveProperty(epiString.pascalToCamel(this.activePropertyOnStartup));
                this.activePropertyOnStartup = null;
            }
        },
        _getPropertyNodes: function (doc) {
            var allNodes = query("[data-epi-edit], [data-epi-property-name]", doc);
            // Write out all the combinations of nested nodes to avoid runtime calculations which would always give the same result.
            var nestedNodes = query("[data-epi-edit] [data-epi-edit], [data-epi-property-name] [data-epi-property-name], [data-epi-property-name] [data-epi-edit], [data-epi-edit] [data-epi-property-name]", doc);
            return array.filter(allNodes, function (node) {
                // return the nodes that are not nested
                return nestedNodes.indexOf(node) === -1;
            });
        },
        _getOverlayParameters: function (nodes, isExternal) {
            var result = [];
            array.forEach(nodes, function (node) {
                var dataset = node.dataset;
                var propertyNodeName = epiString.pascalToCamel(dataset.epiEdit || dataset.epiPropertyName);
                var propertyMetadata = this.viewModel.getPropertyMetaData(propertyNodeName);
                var useNullRenderer = isExternal || !!dataset.epiEdit;
                // Skip this property if we don't have metadata,
                // i.e. the template rendered a node we won't find in the model
                if (!propertyMetadata) {
                    return;
                }
                // readOnly property is not editable
                if (propertyMetadata.settings && propertyMetadata.settings.readOnly) {
                    return;
                }
                // Get the real property name from metadata, since the page property name may be the legacy name (e.g. pageName -> icontent_name)
                var propertyName = epiString.pascalToCamel(propertyMetadata.getName());
                var propertyDisplayName = dataset.epiPropertyDisplayName;
                if (propertyDisplayName) {
                    propertyMetadata = lang.delegate(propertyMetadata, { displayName: propertyDisplayName });
                }
                if (propertyMetadata != null && propertyMetadata.showForEdit) {
                    // Extract block information from the data attributes
                    // add to result array
                    var renderSettings = {
                        cacheResults: true,
                        rerenderOnCancel: false,
                        propertyRenderSettings: dataset.epiPropertyRendersettings || undefined
                    };
                    renderSettings = lang.mixin(renderSettings, propertyMetadata.additionalValues.renderSettings);
                    // Read custom renderer settings from the data attribute resolving any name aliases if needed,
                    // or use the metadata if the attribute is empty.
                    var rendererClass = useNullRenderer ? "none" : dataset.epiPropertyRender || propertyMetadata.customEditorSettings.rendererClass;
                    switch (rendererClass) {
                        case "partial":
                            rendererClass = "epi-cms/contentediting/PropertyRenderer";
                            break;
                        case "client":
                            rendererClass = "epi-cms/contentediting/ClientRenderer";
                            break;
                        case "none":
                        case "full":
                            rendererClass = "epi-cms/contentediting/NullRenderer";
                            break;
                    }
                    var editorParams = JSON.parse(dataset.epiPropertyEditorsettings || null);
                    var overlayParams = JSON.parse(dataset.epiPropertyOverlaysettings || null);
                    overlayParams = lang.mixin(overlayParams, propertyMetadata.overlaySettings);
                    // Disable custom OPE editor and wrapper type since we want to force floating editors.
                    if (dataset.epiEdit) {
                        propertyMetadata.customEditorSettings.uiType = null;
                        propertyMetadata.customEditorSettings.uiWrapper = null;
                    }
                    result.push({
                        node: node,
                        disabled: dataset.epiDisabled === "true",
                        useOverlay: dataset.epiUseoverlay === "true",
                        overlayZIndex: parseInt(dataset.epiOverlayZIndex, 10) || 0,
                        uniqueName: node.uniqueName,
                        elementPosition: node.elementPosition,
                        property: {
                            name: propertyName,
                            contentLink: this.viewModel.contentLink,
                            contentModel: this.viewModel.contentModel,
                            type: dataset.epiPropertyType,
                            wrapperType: isExternal || dataset.epiEdit ? "floating" : dataset.epiPropertyEdittype || null,
                            editorParams: editorParams,
                            overlayParams: overlayParams,
                            editorWidgetType: dataset.epiPropertyEditor,
                            renderSettings: renderSettings,
                            rendererClass: rendererClass,
                            metadata: propertyMetadata,
                            propertyNodeName: propertyNodeName
                        }
                    });
                }
            }, this);
            // sort editable nodes depending on z-index-hint
            result.sort(function (a, b) {
                // use reverse index, higher values later in array
                if (a.overlayZIndex < b.overlayZIndex) {
                    return -1;
                }
                else if (a.overlayZIndex > b.overlayZIndex) {
                    return 1;
                }
                else {
                    return 0;
                }
            });
            return result;
        },
        _getEditableNodes: function (doc) {
            // summary:
            //    Create the editable blocks and wire up events.
            //
            // tags:
            //    private
            // Cannot inspect document, assume that we have no editable node.
            if (!doc || !this.viewModel.canChangeContent()) {
                return [];
            }
            var nodes = this._getPropertyNodes(doc);
            // default is inline-editors, optimized for delivery, limitUI, will cause floating editors
            var isExternal = ApplicationSettings.limitUI;
            return this._getOverlayParameters(nodes, isExternal);
        },
        _getEditableNodesFromEpiProps: function (props) {
            // summary:
            //    Create the editable blocks and wire up events.
            //
            // tags:
            //    private
            // No properties exists, assume that we have no editable node.
            if (!props || !this.viewModel.canChangeContent()) {
                return [];
            }
            // default is inline-editors, optimized for delivery, limitUI, will cause floating editors
            var isExternal = ApplicationSettings.limitUI;
            return this._getOverlayParameters(props, isExternal);
        },
        _createUpdateControllers: function (doc, props) {
            // summary:
            //    Create the editable blocks and wire up events.
            //
            // doc: Document
            //    Document where to get editable blocks.
            //
            // tags:
            //    private
            //Create a full page update controller
            var fullpageUpdateController = this._createFullPageUpdateController(doc);
            if (fullpageUpdateController) {
                this._connectFullPageUpdateControllerEvents(fullpageUpdateController);
                this._mappingManager.add({
                    updateController: fullpageUpdateController
                });
            }
            //Create update controllers for nodes
            var editableNodes = null;
            if (doc) {
                editableNodes = this._getEditableNodes(doc);
            }
            else if (props) {
                editableNodes = this._getEditableNodesFromEpiProps(props);
            }
            array.forEach(editableNodes, function (editableNode) {
                var property = editableNode.property;
                var nodeHTML = editableNode.node.innerHTML;
                var updateController = this._createNodeUpdateController(editableNode);
                when(this._createNodeOverlay(editableNode), lang.hitch(this, function (overlayItem) {
                    if (overlayItem) {
                        overlayItem.uniqueName = editableNode.uniqueName;
                    }
                    this._connectUpdateControllerAndOverlayEvents(updateController, overlayItem);
                    // create mapping
                    this._mappingManager.add({
                        blockPropertyInfo: property,
                        node: editableNode.node,
                        updateController: updateController,
                        overlayItem: overlayItem
                    });
                }));
                //Cache the block's initial rendering.
                this._renderManager.cacheRender(property.name, property.renderSettings, this.viewModel.getProperty(property.name), nodeHTML);
            }, this);
        },
        _createNodeOverlay: function (editableNode) {
            // summary:
            //      Change to use dojo/Deferred because of overlayFactory now use this way
            var deferred = new Deferred();
            // Don't create overlay
            if (!this.createOverlays) {
                deferred.resolve(null);
                return deferred;
            }
            when(overlayFactory.create(editableNode), lang.hitch(this, function (overlayItem) {
                this.overlay.addChild(overlayItem);
                if (ApplicationSettings.limitUI === true) {
                    overlayItem.updatePosition(editableNode.elementPosition);
                }
                deferred.resolve(overlayItem);
            }));
            return deferred;
        },
        _createNodeUpdateController: function (editableNode) {
            var property = editableNode.property;
            var metadata = property.metadata;
            // Create block
            var updateController = new UpdateController({
                displayName: metadata.displayName,
                renderManager: this._renderManager,
                contentModel: property.contentModel,
                contentLink: property.contentLink,
                modelPropertyName: property.name,
                nodePropertyName: property.propertyNodeName,
                renderSettings: property.renderSettings,
                rendererClass: property.rendererClass,
                displayNode: editableNode.node
            });
            return updateController;
        },
        _createFullPageUpdateController: function (doc) {
            var fullreloadProperties = [];
            // Get full page reload properties from template
            if (doc) {
                var metaTags = query("input[data-epi-full-refresh-property-names][type='hidden']", doc);
                array.forEach(metaTags, function (tag) {
                    array.forEach(tag.dataset.epiFullRefreshPropertyNames.split(","), function (propertyName) {
                        if (!array.some(fullreloadProperties, function (p) {
                            return p === propertyName;
                        })) {
                            fullreloadProperties.push(epiString.pascalToCamel(propertyName));
                        }
                    });
                });
            }
            // Get full page reload properties from metadata
            array.forEach(this.viewModel.metadata.properties, function (property) {
                if (property.additionalValues["reloadOnChange"] === true) {
                    fullreloadProperties.push(epiString.pascalToCamel(property.name));
                }
            });
            if (!fullreloadProperties.length) {
                return null;
            }
            //create a full page update controller
            var pageUpdateController = new UpdateController({
                displayName: "",
                renderManager: this._renderManager,
                contentModel: this.viewModel.contentModel,
                modelPropertyName: fullreloadProperties,
                renderSettings: { isFullReload: true }
            });
            return pageUpdateController;
        },
        _remapUpdateControllers: function (doc) {
            var editableNodes = this._getEditableNodes(doc);
            // Remap update controller that connected to old nodes. Also remove the old fullpage update controller
            var unmappedNodes = this._mappingManager.remap(editableNodes);
            //Create new update controllers for nodes that was newly added
            array.forEach(unmappedNodes, function (editableNode) {
                var property = editableNode.property;
                var updateController = this._createNodeUpdateController(editableNode);
                when(this._createNodeOverlay(editableNode), lang.hitch(this, function (overlayItem) {
                    this._connectUpdateControllerAndOverlayEvents(updateController, overlayItem);
                    this._mappingManager.add({
                        blockPropertyInfo: property,
                        node: editableNode.node,
                        updateController: updateController,
                        overlayItem: overlayItem
                    });
                }));
                //Cache the block's initial rendering.
                this._renderManager.cacheRender(property.name, property.renderSettings, this.viewModel.getProperty(property.name), editableNode.node.innerHTML);
            }, this);
            // Recreate new fullpage update controller
            var fullpageUpdateController = this._createFullPageUpdateController(doc);
            if (fullpageUpdateController) {
                this._connectFullPageUpdateControllerEvents(fullpageUpdateController);
                this._mappingManager.add({
                    updateController: fullpageUpdateController
                });
            }
        },
        _connectUpdateControllerAndOverlayEvents: function (updateController, overlayItem) {
            if (updateController) {
                this.ownByKey("overlay", aspect.after(updateController, "onReloadRequired", lang.hitch(this, this._onBlockReloadRequired), true), aspect.after(updateController, "onRender", lang.hitch(this, this._onBlockRender), true));
            }
            if (overlayItem) {
                this.ownByKey("overlay", aspect.after(overlayItem, "onClick", lang.hitch(this, this._onOverlayItemClick), true), aspect.after(overlayItem, "onValueChange", lang.hitch(this, function (value) {
                    this._onOverlayValueChange(overlayItem, value);
                }), true));
            }
        },
        _connectFullPageUpdateControllerEvents: function (fullpageUpdateController) {
            this.destroyByKey("fullpageoverlay");
            this.ownByKey("fullpageoverlay", aspect.after(fullpageUpdateController, "onReloadRequired", this._onBlockReloadRequired.bind(this), true), aspect.after(fullpageUpdateController, "onRender", this._onBlockRender.bind(this), true));
        },
        _getEditor: function (/*Object*/ overlayItem) {
            // summary:
            //      Get wrapper editor
            // overlayItem:
            //      Current overlay item that accepting drop
            // tags:
            //      private
            var mapping = this._mappingManager.findOne("overlayItem", overlayItem);
            return (mapping && mapping.wrapper && mapping.wrapper.editorWidget) ? mapping.wrapper.editorWidget : null;
        },
        onEditorWrapperCreated: function (/*Object*/ editorWrapper) {
            // summary:
            //      Triggered when the active editor wrapper created.
            //
            // editorWrapper:
            //      The created editor wrapper
            //
            // tags:
            //    public, callback
        },
        _onOverlayItemClick: function (overlayItem) {
            // Do not continue if a wrapper is already being created
            if (this._isCreatingWrapper) {
                return;
            }
            this._isCreatingWrapper = true;
            var mapping = this._mappingManager.findOne("overlayItem", overlayItem);
            var property = mapping.blockPropertyInfo;
            var val = this.viewModel.getProperty(mapping.propertyName);
            var value = lang.clone(val, true);
            var wrapper;
            var wrapperCreated = lang.hitch(this, function (wrapper) {
                // store wrapper if we want to reuse it
                mapping.wrapper = wrapper;
                this._activeEditorWrapper = wrapper;
                topic.publish("/epi/layout/pinnable/propertyEditor/show", null);
                // TODO: force a save for legacy properties? or close open currentWrapper
                // if saving: use deferred to not open this wrapper until save is done
                array.forEach(this._mappingManager.find(), function (m) {
                    if (m.overlayItem) {
                        m.overlayItem.set("active", false);
                    }
                });
                mapping.overlayItem.set("active", true);
                // start editing
                var editorParams = { value: value, parent: wrapper };
                when(wrapper.startEdit(editorParams)).always(lang.hitch(this, function () {
                    this._isCreatingWrapper = null;
                }));
                this.overlay.set("readOnly", wrapper.isOverlayDisabled);
                this.viewModel.set("disableUndo", wrapper.isUndoDisabled);
            });
            if (mapping.wrapper) {
                wrapper = mapping.wrapper;
                if (wrapper && wrapper.editorWidget && !wrapper.editorWidget.overlayItem) {
                    wrapper.editorWidget.overlayItem = overlayItem;
                }
                wrapper.set("blockDisplayNode", mapping.node);
                wrapperCreated(wrapper);
            }
            else {
                // create new wrapper
                when(this._createEditorWrapper(property, overlayItem, mapping.node, value), lang.hitch(this, function (wrapper) {
                    wrapperCreated(wrapper);
                    this.onEditorWrapperCreated(wrapper);
                }));
            }
        },
        _createEditorWrapper: function (property, overlayItem, node, value) {
            // summary:
            //		Create editor wrapper for property in template.
            // description:
            //      By default, editor wrappers are created using EditorFactory. Override to implement custom creation, for example: FormEditing creates FormEditorWrapper all the times
            // tags:
            //		protected
            var def = new Deferred(), options = { overlayItem: overlayItem };
            when(this.editorFactory.createEditor(property, node, value, options), lang.hitch(this, function (wrapper) {
                this.ownByKey("overlay", aspect.after(wrapper, "onValueChange", lang.hitch(this, this._onWrapperValueChange), true), aspect.after(wrapper, "onCancel", lang.hitch(this, this._onWrapperCancel), true), aspect.after(wrapper, "onStopEdit", lang.hitch(this, this._onWrapperStopEdit), true));
                def.resolve(wrapper);
            }), def.reject);
            return def;
        },
        _onBlockReloadRequired: function () {
            var reload = function () {
                // If currently editing inline, don't reload
                if (this._activeEditorWrapper && this._activeEditorWrapper.hasInlineEditor) {
                    return;
                }
                if (this._deferredReloadHandle) {
                    this._deferredReloadHandle.remove();
                    this._deferredReloadHandle = null;
                }
                this.onReloadRequired();
            }.bind(this);
            if (this.viewModel.isSaved) {
                reload();
            }
            else {
                if (!this._deferredReloadHandle) {
                    this.own(this._deferredReloadHandle = aspect.after(this.viewModel, "onPropertySaved", reload, true));
                }
            }
        },
        _onBlockRender: function (updateController) {
            var mapping = this._mappingManager.findOne("updateController", updateController);
            if (mapping && mapping.overlayItem) {
                mapping.overlayItem.refresh();
            }
        },
        _saveEditorChanges: function (/*Object*/ overlayItem, /*Object*/ data) {
            // summary:
            //      Update active editor widget value
            // overlayItem:
            //      Current overlay item that accepting drop
            // data:
            //      Array of objects
            // tags:
            //      private
            var editor = this._getEditor(overlayItem);
            if (editor && !editor.overlayItem) {
                editor.overlayItem = overlayItem;
            }
            if (editor && editor.saveChanges) {
                editor.saveChanges(editor, data);
            }
        },
        _onOverlayValueChange: function (overlayItem, data) {
            // summary:
            //      Handler for single or multiple property changes
            // overlayItem: Object
            //      Current overlay item that accepting drop
            // data: Object || Array
            //      The properties to change n format {propertyName: "myName", value: propertyValue}
            // tags:
            //      Private
            this._saveEditorChanges(overlayItem, data.value);
            this.viewModel.setProperty(data.propertyName, data.value);
        },
        _onWrapperValueChange: function (wrapper, value, oldValue) {
            var mapping = this._mappingManager.findOne("wrapper", wrapper), propertyName = mapping.propertyName;
            // If this change from dnd then it will saved when "/dnd/stop"
            if (mapping.overlayItem) {
                mapping.overlayItem.set("updated", true);
            }
            // Begin an operation if not already started
            this.viewModel.beginOperation();
            // Save the property
            this.viewModel.setProperty(propertyName, value, oldValue);
        },
        _onWrapperStopEdit: function (wrapper, value, oldValue, implicitExit) {
            var mapping = this._mappingManager.findOne("wrapper", wrapper);
            // End the ongoing operation, commit the value
            this.viewModel.endOperation();
            if (mapping && mapping.overlayItem) {
                mapping.overlayItem.set("active", false);
            }
            this._activeEditorWrapper = null;
            this.overlay.set("readOnly", false);
            this.viewModel.set("disableUndo", false);
        },
        _onWrapperCancel: function (wrapper, implicitExit) {
            var mapping = this._mappingManager.findOne("wrapper", wrapper), updateController = mapping.updateController;
            // Abort the current operation
            this.viewModel.abortOperation();
            // force re-render on block if it has rerenderOnCancel
            if (updateController && updateController.renderSettings && updateController.renderSettings.rerenderOnCancel) {
                updateController.render();
            }
            if (mapping && mapping.overlayItem) {
                mapping.overlayItem.set("active", false);
            }
            this._activeEditorWrapper = null;
            this.overlay.set("readOnly", false);
            this.viewModel.set("disableUndo", false);
        },
        _onPropertyReverted: function (propertyName, oldValue) {
            this._mappingManager.find("propertyName", propertyName).forEach(function (mapping) {
                var wrapper = mapping && mapping.wrapper, editing;
                if (wrapper) {
                    editing = wrapper.get("editing");
                    wrapper.set("editing", false);
                    wrapper.set("value", oldValue);
                    wrapper.set("editing", editing);
                }
            });
        }
    });
});
